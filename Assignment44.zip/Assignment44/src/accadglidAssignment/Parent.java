package accadglidAssignment;

public class Parent {

	public Parent()
	{
		System.out.println("Parent default constructor");
	}
	public Parent(String name)
	{
		this();
		System.out.println("Parent parametrized constructor" + name);
	}
}
