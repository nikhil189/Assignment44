package accadglidAssignment;

public class Child extends Parent {
	public Child()
	{
		super();
		System.out.println(" Child Default Constructor");
	}
	public Child(String str)
	{
		this();
		System.out.println(" Child parametrized Constructor");
	}
	public Child(int i)
	{
		super("   yup");
	}
	public static void main(String ...k)
	{
		Child obj =  new Child();
		Child obj1 = new Child("test");
		Child obj2 = new Child(1);
	}
	
}
